<div class="footer">
    <p>&copy; 2024 VSL CTF Team. All rights reserved.</p>
</div>
<?php include 'views/login_modal.php'; ?>

<script src="assets/js/scripts.js"></script>
</body>

</html>