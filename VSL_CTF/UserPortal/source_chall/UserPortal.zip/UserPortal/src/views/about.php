<div class="container">
    <h2>About Us</h2>
    <p>Welcome to the User Portal. We are dedicated to providing the best user experience with our web application.
        Explore the features and enjoy your stay!</p>
</div>